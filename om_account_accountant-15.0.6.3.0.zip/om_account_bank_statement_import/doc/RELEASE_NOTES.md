## Module <om_account_bank_statement_import>

#### 30.07.2022
#### Version 15.0.2.4.0
##### IMP
- date format in validation message

#### 16.07.2022
#### Version 15.0.2.3.0
##### IMP
- validation error for wrong file format

#### 15.04.2022
#### Version 15.0.2.2.0
##### IMP
- turkish translation

#### 20.12.2021
#### Version 15.0.2.0.0
##### FIX
- access right error
